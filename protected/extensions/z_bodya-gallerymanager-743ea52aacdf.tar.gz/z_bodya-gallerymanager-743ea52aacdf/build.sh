#!/usr/bin/env sh

uglifyjs -m --unsafe -o ./assets/jquery.galleryManager.min.js ./assets/jquery.galleryManager.js
uglifyjs -m --unsafe -o ./assets/jquery.iframe-transport.min.js ./assets/jquery.iframe-transport.js
 